package com.qj.schedule.service;


public interface Callback {
	
	
	public void callback();
	
	
}
